import tkinter as tk
import random

BOARD_SIZE = 7
PLAYER1_PIECE = '\u25B2'  # Triangle
PLAYER2_PIECE = '\u25CF'  # Circle
EMPTY_CELL = '.'


class StrategicBoardGameGUI:
    def __init__(self, root):
        self.root = root
        self.current_player = 1
        self.board = [[EMPTY_CELL for _ in range(BOARD_SIZE)] for _ in range(BOARD_SIZE)]

        # Taşların ilk konumları
        self.piece_positions = {
            1: [(0, 0), (2, 0), (4, 6), (6, 6)],
            2: [(0, 6), (2, 6), (4, 0), (6, 0)]
        }

        self.selected_piece = None
        self.move_count = 0

        # Geliştirilmiş memo: (board_state, depth, is_maximizing) -> skor
        self.memo = {}

        self.init_board()
        self.create_gui()

    def init_board(self):
        for player, positions in self.piece_positions.items():
            for x, y in positions:
                self.board[x][y] = PLAYER1_PIECE if player == 1 else PLAYER2_PIECE

    def create_gui(self):
        self.canvas = tk.Canvas(self.root, width=350, height=350)
        self.canvas.pack()

        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()
        width, height = 350, 375
        x = int((screen_width / 2) - (width / 2))
        y = int((screen_height / 2) - (height / 2))
        self.root.geometry(f"{width}x{height}+{x}+{y}")

        current_symbol = PLAYER1_PIECE if self.current_player == 1 else PLAYER2_PIECE
        self.status_bar = tk.Label(self.root,
                                   text=f"Player {self.current_player}'s Turn {current_symbol}",
                                   font=("Arial", 16), bg="lightgray", anchor="center")
        self.status_bar.pack(side=tk.BOTTOM, fill=tk.X)

        self.draw_board()
        self.canvas.bind("<Button-1>", self.on_click)

    def draw_board(self):
        self.canvas.delete("all")
        cell_size = 50
        for i in range(BOARD_SIZE):
            for j in range(BOARD_SIZE):
                x0, y0 = j * cell_size, i * cell_size
                x1, y1 = x0 + cell_size, y0 + cell_size
                self.canvas.create_rectangle(x0, y0, x1, y1, fill="yellow", outline="black", width=2)
                if self.board[i][j] != EMPTY_CELL:
                    self.canvas.create_text((x0 + x1) // 2, (y0 + y1) // 2,
                                            text=self.board[i][j], font=("Arial", 24))

    def switch_player(self):
        self.current_player = 2 if self.current_player == 1 else 1
        current_symbol = PLAYER1_PIECE if self.current_player == 1 else PLAYER2_PIECE
        self.status_bar.config(text=f"Player {self.current_player}'s Turn {current_symbol}")

        if self.current_player == 2:
            self.ai_move()

    def on_click(self, event):
        # Sadece Player 1 (insan) hamle yapabilsin
        if self.current_player != 1:
            return

        cell_size = 50
        row, col = event.y // cell_size, event.x // cell_size

        if self.selected_piece:
            # Geçerli hamle mi kontrol et
            if self.is_valid_move(self.selected_piece, (row, col)):
                self.make_move(self.selected_piece, (row, col))
                self.move_count += 1  # Her hamlede artıyor
                self.check_capture_all()
                self.selected_piece = None

                # Oyun bitti mi kontrol et
                if not self.check_game_over():
                    self.switch_player()
            else:
                self.selected_piece = None
        else:
            # Henüz seçili bir taş yoksa ve tıklanan hücre bize aitse seç
            if self.board[row][col] == PLAYER1_PIECE:
                self.selected_piece = (row, col)

        self.draw_board()

    def is_valid_move(self, start, end):
        sx, sy = start
        ex, ey = end

        # Tahta sınırında mıyız
        if not (0 <= ex < BOARD_SIZE and 0 <= ey < BOARD_SIZE):
            return False

        # Gideceğimiz yer boş olmalı
        if self.board[ex][ey] != EMPTY_CELL:
            return False

        # Dikey/ yatay tek adım ilerleme kontrolü
        if (sx == ex and abs(sy - ey) == 1) or (sy == ey and abs(sx - ex) == 1):
            return True

        return False

    def make_move(self, start, end):
        sx, sy = start
        ex, ey = end
        self.board[ex][ey] = self.board[sx][sy]
        self.board[sx][sy] = EMPTY_CELL

    def check_capture_all(self):
        """ Hareket sonrası oluşan kuşatmaları tespit edip ele geçirilen taşları temizler. """
        opponent_piece = PLAYER2_PIECE if self.current_player == 1 else PLAYER1_PIECE
        my_piece = self.board
        captured_positions = []
        visited = set()

        # Mevcut oyuncunun taş gruplarını arıyoruz
        # (Düşmana ait taşlar da kuşatılmış olabilir;
        #  eğer oyunda kural: 'hamleyi yapan, rakip grubunu mu kuşatır?' ise ek uyarlamalar gerekebilir)
        for i in range(BOARD_SIZE):
            for j in range(BOARD_SIZE):
                if (self.board[i][j] ==
                    (PLAYER1_PIECE if self.current_player == 1 else PLAYER2_PIECE)) and (i, j) not in visited:
                    group = self.find_group(i, j, self.board[i][j])
                    visited.update(group)
                    # Kuşatıldı mı kontrol
                    if self.is_group_surrounded(group, opponent_piece):
                        captured_positions.extend(group)

        for x, y in captured_positions:
            self.board[x][y] = EMPTY_CELL

    def find_group(self, x, y, piece):
        """ x,y noktasındaki taşla bağlantılı tüm taşların koordinatlarını döndürür. """
        group = []
        visited = set()
        self._dfs(x, y, piece, visited, group)
        return group

    def _dfs(self, x, y, piece, visited, group):
        if (x, y) in visited:
            return
        if not (0 <= x < BOARD_SIZE and 0 <= y < BOARD_SIZE):
            return
        if self.board[x][y] != piece:
            return

        visited.add((x, y))
        group.append((x, y))

        for dx, dy in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
            self._dfs(x + dx, y + dy, piece, visited, group)

    def is_group_surrounded(self, group, opponent_piece):
        """
        Basit kuşatma kuralı: bir grup, her yönden rakip taşlarıyla
        'aynı satır veya aynı sütunda' mı çevrili diye bakıyoruz.
        (Mevcut is_group_surrounded mantığı oyundan oyuna değişebilir.)
        """
        for gx, gy in group:
            row_blocked = True
            for y_ in [gy - 1, gy + 1]:
                if 0 <= y_ < BOARD_SIZE:
                    if self.board[gx][y_] != opponent_piece:
                        row_blocked = False

            col_blocked = True
            for x_ in [gx - 1, gx + 1]:
                if 0 <= x_ < BOARD_SIZE:
                    if self.board[x_][gy] != opponent_piece:
                        col_blocked = False

            # Hem satır hem sütun rakip tarafından bloklanmadıkça "kuşatıldı" sayılmasın
            if not (row_blocked or col_blocked):
                return False

        return True

    def ai_move(self):
        """ Yapay zekanın (Player2) hamle seçimi. """
        possible_moves = self.get_all_possible_moves(2)
        if not possible_moves:
            # Hamle yoksa el değiştirelim
            self.status_bar.config(text="Player 1 Wins! (AI has no moves)")
            return

        best_score = float('-inf')
        best_moves = []

        # Dinamik derinlik örneği (move_count arttıkça daha zeki ama daha yavaş hesaplama)
        if self.move_count < 10:
            depth = 3
        else:
            depth = 5

        # Hamle sıralaması (move ordering) için basit bir yaklaşım:
        # Önce, simulate_move sonrası evaluate_board skoruna göre sıralıyoruz
        moves_with_score = []
        for move in possible_moves:
            new_board = self.simulate_move(self.board, move)
            eval_score = self.evaluate_board(new_board)
            moves_with_score.append((move, eval_score))

        # Daha iyi (yüksek) skorlu hamleleri önce deneyeceğiz
        moves_with_score.sort(key=lambda x: x[1], reverse=True)

        for (move, _) in moves_with_score:
            new_board = self.simulate_move(self.board, move)
            score = self.alphabeta(new_board, depth, float('-inf'), float('inf'), False)

            if score > best_score:
                best_score = score
                best_moves = [move]
            elif score == best_score:
                best_moves.append(move)

        best_move = random.choice(best_moves)
        self.make_move(best_move[0], best_move[1])
        self.move_count += 1
        self.check_capture_all()
        self.draw_board()

        if not self.check_game_over():
            self.switch_player()

    def alphabeta(self, board, depth, alpha, beta, is_maximizing):
        """ Geliştirilmiş alpha-beta fonksiyonu. """
        # Transposition table için key üret
        board_key = (tuple(tuple(row) for row in board), depth, is_maximizing)
        if board_key in self.memo:
            return self.memo[board_key]

        # Oyun bitmiş ya da derinlik tükendi ise skor
        if depth == 0 or self._check_game_over_static(board):
            score = self.evaluate_board(board)
            self.memo[board_key] = score
            return score

        if is_maximizing:
            max_eval = float('-inf')
            moves = self.get_all_possible_moves_static(board, 2)

            # Basit move ordering: hamleleri skor önceliğine göre sıralayabiliriz
            # (Daha hızlı bir yol: yine evaluate_board çağırmak)
            moves_with_score = []
            for m in moves:
                new_b = self.simulate_move(board, m)
                sc = self.evaluate_board(new_b)
                moves_with_score.append((m, sc))
            moves_with_score.sort(key=lambda x: x[1], reverse=True)

            for (move, _) in moves_with_score:
                new_board = self.simulate_move(board, move)
                eval_ = self.alphabeta(new_board, depth - 1, alpha, beta, False)
                max_eval = max(max_eval, eval_)
                alpha = max(alpha, eval_)
                if beta <= alpha:
                    break

            self.memo[board_key] = max_eval
            return max_eval

        else:
            min_eval = float('inf')
            moves = self.get_all_possible_moves_static(board, 1)

            # Sıralama
            moves_with_score = []
            for m in moves:
                new_b = self.simulate_move(board, m)
                sc = self.evaluate_board(new_b)
                moves_with_score.append((m, sc))
            moves_with_score.sort(key=lambda x: x[1])  # Minimizing, küçük skor önce

            for (move, _) in moves_with_score:
                new_board = self.simulate_move(board, move)
                eval_ = self.alphabeta(new_board, depth - 1, alpha, beta, True)
                min_eval = min(min_eval, eval_)
                beta = min(beta, eval_)
                if beta <= alpha:
                    break

            self.memo[board_key] = min_eval
            return min_eval

    def simulate_move(self, board, move):
        """ Verilen board üzerinde move uygulanarak oluşan yeni board döndürür. """
        new_board = [row[:] for row in board]  # Derin kopya
        sx, sy = move[0]
        ex, ey = move[1]

        new_board[ex][ey] = new_board[sx][sy]
        new_board[sx][sy] = EMPTY_CELL
        return new_board

    def get_all_possible_moves(self, player):
        """ Mevcut self.board'a göre player'ın tüm yasal hamlelerini döndürür. """
        piece = PLAYER2_PIECE if player == 2 else PLAYER1_PIECE
        moves = []
        for i in range(BOARD_SIZE):
            for j in range(BOARD_SIZE):
                if self.board[i][j] == piece:
                    for dx, dy in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                        nx, ny = i + dx, j + dy
                        if 0 <= nx < BOARD_SIZE and 0 <= ny < BOARD_SIZE:
                            if self.board[nx][ny] == EMPTY_CELL:
                                moves.append(((i, j), (nx, ny)))
        return moves

    # Statik fonksiyonlar: alphabeta içinde "gelecekteki" board için de geçerli olsun diye
    def get_all_possible_moves_static(self, board, player):
        piece = PLAYER2_PIECE if player == 2 else PLAYER1_PIECE
        moves = []
        for i in range(BOARD_SIZE):
            for j in range(BOARD_SIZE):
                if board[i][j] == piece:
                    for dx, dy in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                        nx, ny = i + dx, j + dy
                        if 0 <= nx < BOARD_SIZE and 0 <= ny < BOARD_SIZE and board[nx][ny] == EMPTY_CELL:
                            moves.append(((i, j), (nx, ny)))
        return moves

    def evaluate_board(self, board=None):
        """
        Geliştirilmiş değerlendirme fonksiyonu:
        1) Taş sayısı
        2) Kuşatma bonusu
        3) Merkez bonusu
        4) İsterseniz ekstra kriterler ekleyebilirsiniz
        """
        if board is None:
            board = self.board

        player1_score = sum(row.count(PLAYER1_PIECE) for row in board)
        player2_score = sum(row.count(PLAYER2_PIECE) for row in board)

        # Player2'nin (AI) rakip taşları kuşatabilme bonusu
        # Her kuşatılan grup için +3 puan örneği
        player2_capture_bonus = 0
        for x in range(BOARD_SIZE):
            for y in range(BOARD_SIZE):
                if board[x][y] == PLAYER1_PIECE:
                    group = self.find_group_static(board, x, y, PLAYER1_PIECE)
                    if self.is_group_surrounded_static(board, group, PLAYER2_PIECE):
                        # Grubu tamamen kuşattıysa +3 (dilerseniz arttırabilirsiniz)
                        player2_capture_bonus += 3

        # Merkez bölgede (keyfi seçilmiş birkaç hücre) AI taşı varsa ekstra bonus
        # Daha kapsamlı bir “merkez” tanımı yapılabilir.
        center_coords = [(2, 3), (3, 2), (3, 3), (3, 4), (4, 3)]
        center_bonus_player2 = 0
        for (cx, cy) in center_coords:
            if 0 <= cx < BOARD_SIZE and 0 <= cy < BOARD_SIZE:
                if board[cx][cy] == PLAYER2_PIECE:
                    center_bonus_player2 += 2

        # Nihai skor
        score = (player2_score + player2_capture_bonus + center_bonus_player2) - player1_score
        return score

    # Oyun bitiş kontrolü
    def check_game_over(self):
        player1_pieces = sum(row.count(PLAYER1_PIECE) for row in self.board)
        player2_pieces = sum(row.count(PLAYER2_PIECE) for row in self.board)

        if player1_pieces == 0:
            self.status_bar.config(text="Player 2 Wins!")
            return True
        elif player2_pieces == 0:
            self.status_bar.config(text="Player 1 Wins!")
            return True
        elif self.move_count >= 50:
            self.status_bar.config(text="It's a Draw!")
            return True
        return False

    # Alpha-beta içinde statik olarak kullanacağımız "oyun bitti mi" kontrolü
    def _check_game_over_static(self, board):
        # Eğer Player1 veya Player2 tamamen bitti ise oyun bitmiş kabul.
        player1_pieces = sum(row.count(PLAYER1_PIECE) for row in board)
        player2_pieces = sum(row.count(PLAYER2_PIECE) for row in board)
        if player1_pieces == 0 or player2_pieces == 0:
            return True
        return False

    # Statik "group" fonksiyonları
    def find_group_static(self, board, x, y, piece):
        group = []
        visited = set()
        self._dfs_static(board, x, y, piece, visited, group)
        return group

    def _dfs_static(self, board, x, y, piece, visited, group):
        if (x, y) in visited:
            return
        if not (0 <= x < BOARD_SIZE and 0 <= y < BOARD_SIZE):
            return
        if board[x][y] != piece:
            return
        visited.add((x, y))
        group.append((x, y))
        for dx, dy in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
            self._dfs_static(board, x + dx, y + dy, piece, visited, group)

    def is_group_surrounded_static(self, board, group, opponent_piece):
        for gx, gy in group:
            row_blocked = True
            for y_ in [gy - 1, gy + 1]:
                if 0 <= y_ < BOARD_SIZE:
                    if board[gx][y_] != opponent_piece:
                        row_blocked = False

            col_blocked = True
            for x_ in [gx - 1, gx + 1]:
                if 0 <= x_ < BOARD_SIZE:
                    if board[x_][gy] != opponent_piece:
                        col_blocked = False

            if not (row_blocked or col_blocked):
                return False
        return True


if __name__ == "__main__":
    root = tk.Tk()
    root.title("Strategic Board Game - Improved AI")
    game = StrategicBoardGameGUI(root)
    root.mainloop()
